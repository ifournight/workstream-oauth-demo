export default {
  index: "首页",
  "getting-started": "快速开始",
  "create-client": "创建客户端",
  "get-token": "获取 Token",
  "api-reference": "API 参考",
};
