export default {
  index: "Home",
  "getting-started": "Getting Started",
  "create-client": "Create Client",
  "get-token": "Get Token",
  "api-reference": "API Reference",
};
